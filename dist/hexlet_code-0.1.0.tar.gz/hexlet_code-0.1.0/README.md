### Hexlet tests and linter status:
[![Actions Status](https://github.com/dmsavvin/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/dmsavvin/python-project-49/actions)

### Code Climate badges:
[![Maintainability](https://api.codeclimate.com/v1/badges/7289eeff44509135f2ff/maintainability)](https://codeclimate.com/github/dmsavvin/python-project-49/maintainability)

### Installation and playing process demonstration
[Installation and playing brain-even](https://asciinema.org/a/weOnyiOErqFuYUVo404JisXEo)

[Playing brain-calc](https://asciinema.org/a/wMxcZBo6J1pBZt1fnZY6X1EEs)