### Hexlet tests and linter status:
[![Actions Status](https://github.com/dmsavvin/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/dmsavvin/python-project-49/actions)

### Code Climate badges:
[![Maintainability](https://api.codeclimate.com/v1/badges/7289eeff44509135f2ff/maintainability)](https://codeclimate.com/github/dmsavvin/python-project-49/maintainability)

